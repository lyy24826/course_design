#include "stm32f10x.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "delay.h"
#include "wifi.h"
#include "stdio.h"
#include "trans.h"

extern const unsigned char gImage_gundam[40960];

int main(void)
{
	SysTick_Config(72000);
	Led_Init();
	Key_Init();
	Beep_Init();
	LCD_Init();
	LCD_Fill(0,0,128,160,0x0619);
	LCD_ShowPicture(0,0,128,160,(u8*)gImage_gundam);
	USART2_Config();
	WiFi_Connect();
	node1.Clean_State = 1;
	node1.Eat_State = 2;
	node1.Out_State = 3;
	node1.Wake_State = 4;
	node1.node_addr = 0xABCD;
	
	Usart5_Config();
	int Up_Data=0;
	char Buff[128]={0};
	while(1)
	{
		//���ڽ���
		Trans_Analysis();
		//WiFi����
		WiFi_Analysis();
		if(Led_Time>3000)
		{ 
//			Up_Data++;
//			sprintf(Buff,"cmd=2&uid=8a29f0285554f9387807ebdf529da842&topic=AAA&msg=%d\r\n",Up_Data);
//			Usart2_SendStr(Buff);
			LED3_TURN;
			Led_Time = 0;
		}
			
		switch(Key_Read())
		{
			case 1:
				node1.Clean_State++;
				node1.Eat_State++;
				node1.Out_State++;
				node1.Wake_State++;
				Trans_Data((uint8_t*)&node1,sizeof(node1));break;
			case 2:LED2_TURN;break;
		}
	}
}



