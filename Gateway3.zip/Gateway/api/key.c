#include "key.h"

void Key_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef KEY1={0};
	KEY1.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	KEY1.GPIO_Pin = GPIO_Pin_0;
	KEY1.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOA,&KEY1);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitTypeDef KEY2={0};
	KEY2.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	KEY2.GPIO_Pin = GPIO_Pin_8;
	KEY2.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOB,&KEY2);
}


#include "delay.h"
uint8_t Key_Read(void)
{
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)==SET)
	{
		Delay_ms(30);
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)==SET)
		{
			while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)==SET){}
				return 1;
		}
	}
	
	
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)==RESET)
	{
		Delay_ms(30);
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)==RESET)
		{
			while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)==RESET){}
				return 2;
		}
	}
	
	
	return 0;
}
	
