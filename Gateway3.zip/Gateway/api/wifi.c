#include "wifi.h"
#include "string.h"

void USART2_Config(void)
{
	//�����ô��ڶ�Ӧ��GPIO��TX�������죬RX��������
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef TX={0};
	TX.GPIO_Mode =  GPIO_Mode_AF_PP;
	TX.GPIO_Pin = GPIO_Pin_2;
	TX.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOA,&TX);
	GPIO_InitTypeDef RX={0};
	RX.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	RX.GPIO_Pin = GPIO_Pin_3;
	RX.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOA,&RX);
	//���ô���
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
	USART_InitTypeDef WIFIU={0};
	WIFIU.USART_BaudRate = 115200;
	WIFIU.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	WIFIU.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
	WIFIU.USART_Parity = USART_Parity_No;
	WIFIU.USART_StopBits = USART_StopBits_1;
	WIFIU.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART2,&WIFIU);
	//���������ж�
	USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);
	USART_ITConfig(USART2,USART_IT_IDLE,ENABLE);
	//����NVIC
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef WIFINVIC={0};
	WIFINVIC.NVIC_IRQChannel = USART2_IRQn;
	WIFINVIC.NVIC_IRQChannelCmd = ENABLE;
	WIFINVIC.NVIC_IRQChannelPreemptionPriority = 0x02;
	WIFINVIC.NVIC_IRQChannelSubPriority = 0x01;
	NVIC_Init(&WIFINVIC);
	USART_Cmd(USART2,ENABLE);
}

void Usart2_SendStr(char * p)
{
	while(*p != '\0')
	{
		while(USART_GetFlagStatus(USART2,USART_FLAG_TC)==RESET){}
		USART_SendData(USART2,*p);
		p++;
	}
}


#include "delay.h"
void WiFi_Connect(void)
{
	//����WiFiģ��ΪSTAģʽ
	Usart2_SendStr("AT+WMODE=1,0\r\n");
	Delay_ms(500);
	//�����ȵ�WiFi
	Usart2_SendStr("AT+WJAP=Yao,11111111\r\n");
	Delay_ms(15000);
	//���Ӱͷ��Ʒ�����
	Usart2_SendStr("AT+SOCKET=4,bemfa.com,8344\r\n");
	Delay_ms(2000);
	//����͸��ģʽ
	Usart2_SendStr("AT+SOCKETTT\r\n");
	Delay_ms(1000);
	//���İͷ�������
	Usart2_SendStr("cmd=1&uid=8a29f0285554f9387807ebdf529da842&topic=CLEAN,WAKE,EAT,OUT\r\n");
	Delay_ms(1000);
}

WiFi_DataTypedef WiFi_Data={0};

void USART2_IRQHandler(void)
{
	if(USART_GetITStatus(USART2,USART_IT_RXNE)==SET)
	{
		WiFi_Data.Rx_Buff[WiFi_Data.Rx_Count++] = USART2->DR;
		USART_ClearITPendingBit(USART2,USART_IT_RXNE);
	}
	if(USART_GetITStatus(USART2,USART_IT_IDLE)==SET)
	{
		uint8_t data;
		data = USART2->SR;
		data = USART2->DR;
		WiFi_Data.Rx_Flag = 1;
	}
}

#include "led.h"
void WiFi_Analysis(void)
{
	char * Down_msg = NULL;
	if(WiFi_Data.Rx_Flag==1)
	{
		Down_msg = strstr((char *)WiFi_Data.Rx_Buff, "WAKE");
		u8 Down_data =*(Down_msg+9);
		if(Down_data == '1')//����1����
		{
			BEEP_ON;
		}
		else if(Down_data == '0')
		{
			BEEP_OFF;
		}
		
		WiFi_Data.Rx_Count = 0;
		WiFi_Data.Rx_Flag = 0;
	}
}