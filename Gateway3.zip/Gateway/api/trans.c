#include "trans.h"

void Usart5_Config(void)
{
	//�����ô��ڶ�Ӧ��GPIO��TX�������죬RX��������
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_InitTypeDef TX={0};
	TX.GPIO_Mode =  GPIO_Mode_AF_PP;
	TX.GPIO_Pin = GPIO_Pin_12;
	TX.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOC,&TX);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);
	GPIO_InitTypeDef RX={0};
	RX.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	RX.GPIO_Pin = GPIO_Pin_2;
	RX.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOD,&RX);
	//���ô���
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);
	USART_InitTypeDef TRANS={0};
	TRANS.USART_BaudRate = 9600;
	TRANS.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	TRANS.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
	TRANS.USART_Parity = USART_Parity_No;
	TRANS.USART_StopBits = USART_StopBits_1;
	TRANS.USART_WordLength = USART_WordLength_8b;
	USART_Init(UART5,&TRANS);
	//���������ж�
	USART_ITConfig(UART5,USART_IT_RXNE,ENABLE);
	USART_ITConfig(UART5,USART_IT_IDLE,ENABLE);
	//����NVIC
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef TRANSNVIC={0};
	TRANSNVIC.NVIC_IRQChannel = UART5_IRQn;
	TRANSNVIC.NVIC_IRQChannelCmd = ENABLE;
	TRANSNVIC.NVIC_IRQChannelPreemptionPriority = 0x01;
	TRANSNVIC.NVIC_IRQChannelSubPriority = 0x01;
	NVIC_Init(&TRANSNVIC);
	USART_Cmd(UART5,ENABLE);
}

Trans_DataTypedef TransData={0};

void UART5_IRQHandler(void)
{
	if(USART_GetITStatus(UART5,USART_IT_RXNE)==SET)
	{
		TransData.Rx_Buff[TransData.Rx_Count++] = UART5->DR;
		USART_ClearITPendingBit(UART5,USART_IT_RXNE);
	}
	if(USART_GetITStatus(UART5,USART_IT_IDLE)==SET)
	{
		UART5->SR;
		UART5->DR;
		TransData.Rx_Flag = 1;
	}
}

#include "lcd.h"
#include "stdio.h"
#include "wifi.h"
#include "delay.h"
char Show_Buff[64]={0};
struct NODEX node1={0};
void Trans_Analysis(void)
{
	if(TransData.Rx_Flag == 1)
	{
		node1 = *(struct NODEX*)TransData.Rx_Buff;
		sprintf(Show_Buff,"Clean:%d",node1.Clean_State);
		LCD_ShowString(0,0,(u8*)Show_Buff,BLACK,WHITE,16,0);
		sprintf(Show_Buff,"Eat:%d",node1.Eat_State);
		LCD_ShowString(0,20,(u8*)Show_Buff,BLACK,WHITE,16,0);
		sprintf(Show_Buff,"Wake:%d",node1.Wake_State);
		LCD_ShowString(0,40,(u8*)Show_Buff,BLACK,WHITE,16,0);
		sprintf(Show_Buff,"Out:%d",node1.Out_State);
		LCD_ShowString(0,60,(u8*)Show_Buff,BLACK,WHITE,16,0);
		
		//�����ϴ���ƽ̨
		sprintf(Show_Buff,"cmd=2&uid=8a29f0285554f9387807ebdf529da842&topic=CLEAN&msg=%d",node1.Clean_State);
		Usart2_SendStr(Show_Buff);
		Delay_ms(200);
		sprintf(Show_Buff,"cmd=2&uid=8a29f0285554f9387807ebdf529da842&topic=WAKE&msg=%d",node1.Wake_State);
		Usart2_SendStr(Show_Buff);
		Delay_ms(200);
		sprintf(Show_Buff,"cmd=2&uid=8a29f0285554f9387807ebdf529da842&topic=OUT&msg=%d",node1.Out_State);
		Usart2_SendStr(Show_Buff);
		Delay_ms(200);
		sprintf(Show_Buff,"cmd=2&uid=8a29f0285554f9387807ebdf529da842&topic=EAT&msg=%d",node1.Eat_State);
		Usart2_SendStr(Show_Buff);
		Delay_ms(200);
		TransData.Rx_Flag = 0;
		TransData.Rx_Count = 0;
	}
}



void Trans_Data(uint8_t * p,uint16_t length)
{
	for(int i=0;i<length;i++)
	{
		while(USART_GetFlagStatus(UART5,USART_FLAG_TC)==RESET){}
		USART_SendData(UART5,*p);
		p++;
	}
}



