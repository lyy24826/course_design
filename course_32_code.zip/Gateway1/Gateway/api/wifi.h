#ifndef __WIFI_H
#define __WIFI_H

#include "stm32f10x.h"


typedef struct
{
	uint8_t Rx_Buff[128];
	uint16_t Rx_Count;
	uint8_t Rx_Flag;
}WiFi_DataTypedef;

void USART2_Config(void);
void Usart2_SendStr(char * p);
void WiFi_Connect(void);
void WiFi_Analysis(void);
#endif
