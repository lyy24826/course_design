#ifndef __LED_H
#define __LED_H

#include "stm32f10x.h"

#define LED1_TURN GPIOC->ODR^=1<<0
#define LED2_TURN GPIOC->ODR^=1<<1
#define LED3_TURN GPIOC->ODR^=1<<2



#define BEEP_ON		GPIO_SetBits(GPIOA, GPIO_Pin_6)
#define BEEP_OFF	GPIO_ResetBits(GPIOA, GPIO_Pin_6)

void Led_Init(void);
void Beep_Init(void);
#endif
