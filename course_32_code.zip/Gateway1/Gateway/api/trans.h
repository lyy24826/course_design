#ifndef __TRANS_H
#define __TRANS_H

#include "stm32f10x.h"

//���ڽ������ݻ�����
typedef struct
{
	uint8_t Rx_Buff[128];
	uint16_t Rx_Count;
	uint8_t Rx_Flag;
}Trans_DataTypedef;

//������ݽṹ��
struct NODEX{
  uint16_t node_addr;
	uint16_t close_ok;
	uint16_t warning;
};

extern struct NODEX node1;

void Usart5_Config(void);
void Trans_Analysis(void);
void Trans_Data(uint8_t * p,uint16_t length);
void Trans_Data_MT_UART(uint8_t *data, uint8_t datalen);
#endif
