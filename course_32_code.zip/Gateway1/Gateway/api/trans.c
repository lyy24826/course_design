#include "trans.h"
#include "led.h"
void Usart5_Config(void)
{
	//�����ô��ڶ�Ӧ��GPIO��TX�������죬RX��������
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_InitTypeDef TX={0};
	TX.GPIO_Mode =  GPIO_Mode_AF_PP;
	TX.GPIO_Pin = GPIO_Pin_12;
	TX.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOC,&TX);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);
	GPIO_InitTypeDef RX={0};
	RX.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	RX.GPIO_Pin = GPIO_Pin_2;
	RX.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOD,&RX);
	//���ô���
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);
	USART_InitTypeDef TRANS={0};
	TRANS.USART_BaudRate = 9600;
	TRANS.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	TRANS.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
	TRANS.USART_Parity = USART_Parity_No;
	TRANS.USART_StopBits = USART_StopBits_1;
	TRANS.USART_WordLength = USART_WordLength_8b;
	USART_Init(UART5,&TRANS);
	//���������ж�
	USART_ITConfig(UART5,USART_IT_RXNE,ENABLE);
	USART_ITConfig(UART5,USART_IT_IDLE,ENABLE);
	//����NVIC
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef TRANSNVIC={0};
	TRANSNVIC.NVIC_IRQChannel = UART5_IRQn;
	TRANSNVIC.NVIC_IRQChannelCmd = ENABLE;
	TRANSNVIC.NVIC_IRQChannelPreemptionPriority = 0x01;
	TRANSNVIC.NVIC_IRQChannelSubPriority = 0x01;
	NVIC_Init(&TRANSNVIC);
	USART_Cmd(UART5,ENABLE);
}

Trans_DataTypedef TransData={0};

void UART5_IRQHandler(void)
{
	if(USART_GetITStatus(UART5,USART_IT_RXNE)==SET)
	{
		TransData.Rx_Buff[TransData.Rx_Count++] = UART5->DR;
		USART_ClearITPendingBit(UART5,USART_IT_RXNE);
	}
	if(USART_GetITStatus(UART5,USART_IT_IDLE)==SET)
	{
		UART5->SR;
		UART5->DR;
		TransData.Rx_Flag = 1;
	}
}

#include "lcd.h"
#include "stdio.h"
#include "wifi.h"
#include "delay.h"
char Show_Buff[64]={0};
struct NODEX node1={0};
void Trans_Analysis(void)
{
	if(TransData.Rx_Flag == 1)
	{
		LED2_TURN;
		node1 = *(struct NODEX*)TransData.Rx_Buff;
		LCD_ShowString(0,0,(u8*)"warning the door",0x0619,0x0619,16,0);
		sprintf(Show_Buff,"R-close:%d",node1.close_ok);
		LCD_ShowString(0,0,(u8*)Show_Buff,BLACK,0x0619,16,0);
		LCD_ShowString(0,16,(u8*)"warning the door",0x0619,0x0619,16,0);
		sprintf(Show_Buff,"R-warning:%d",node1.warning);
		LCD_ShowString(0,16,(u8*)Show_Buff,BLACK,0x0619,16,0);
		
		sprintf(Show_Buff,"cmd=2&uid=ac33d2cdcfce49819886f26a07e223ff&topic=CLOSE&msg=%d",node1.close_ok);
		Usart2_SendStr(Show_Buff);
		Delay_ms(200);
		sprintf(Show_Buff,"cmd=2&uid=ac33d2cdcfce49819886f26a07e223ff&topic=WARNING&msg=%d",node1.warning);
		Usart2_SendStr(Show_Buff);
		//Delay_ms(200);
		TransData.Rx_Flag = 0;
		TransData.Rx_Count = 0;
	}
}



void Trans_Data(uint8_t * p,uint16_t length)
{
	for(int i=0;i<length;i++)
	{
		while(USART_GetFlagStatus(UART5,USART_FLAG_TC)==RESET){}
		USART_SendData(UART5,*p);
		p++;
	}
}
void Trans_Data_MT_UART(uint8_t *data, uint8_t datalen)
{
    uint8_t buf[64];
    buf[0] = 0xFE;         // SOF
    buf[1] = datalen;      // LEN
    buf[2] = 0x29;         // CMD0, �Զ���
    buf[3] = 0x00;         // CMD1, �Զ���
    memcpy(&buf[4], data, datalen);

    // ����FCS
    uint8_t fcs = buf[1] ^ buf[2] ^ buf[3];
    for (int i = 0; i < datalen; i++)
        fcs ^= buf[4 + i];
    buf[4 + datalen] = fcs;

    for (int i = 0; i < 5 + datalen; i++)
    {
        while(USART_GetFlagStatus(UART5,USART_FLAG_TC)==RESET){}
        USART_SendData(UART5, buf[i]);
    }
}


