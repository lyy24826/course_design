#include "stm32f10x.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "delay.h"
#include "wifi.h"
#include "stdio.h"
#include "trans.h"

void show_lcd(void);

uint32_t last_send_time = 0;
uint32_t send_interval = 1000; // ÿ1000ms(1��)����һ��
char Buff[128]={0};
int main(void)
{
    SysTick_Config(72000);
    Led_Init();
    Key_Init();
    Beep_Init();
    LCD_Init();
    USART2_Config();
    WiFi_Connect();
    //node1.close_ok = 66;
    //node1.node_addr = 0x0018;
    Usart5_Config();
    LCD_Fill(0,0,128,160,0x0619);
    while(1)
    {
        //���ڽ���
        Trans_Analysis();
				show_lcd();
    }
}

void show_lcd(void)
{
    static uint8_t last_warning = 0xFF; // ��¼��һ��warning״̬����ֵ��Ϊ�����ܵ�ֵ

    // ÿ��1�뷢��һ�����ݲ�ˢ��LCD
    if(Time - last_send_time >= send_interval)
    {
        last_send_time = Time;

        // ��������
        Trans_Data((uint8_t*)&node1, sizeof(node1));
        LED1_TURN;
        // ��ʾ1
				LCD_ShowString(0,48,(u8*)"warning the door",0x0619,0x0619,16,0);
        sprintf(Buff,"T-close:%d",node1.close_ok);
        LCD_ShowString(0,48,(u8*)Buff,BLACK,0x0619,16,0);

        // ��ʾ2warning the door
				LCD_ShowString(0,64,(u8*)"warning the door",0x0619,0x0619,16,0);
        sprintf(Buff,"T-warning:%d",node1.warning);
        LCD_ShowString(0,64,(u8*)Buff,BLACK,0x0619,16,0);
    }

    // �����������߼�
    if(node1.warning == 1 && last_warning != 1)
    {
        BEEP_ON;
        last_warning = 1;
    }
    else if(node1.warning == 0 && last_warning != 0)
    {
        BEEP_OFF;
        last_warning = 0;
    }
}



