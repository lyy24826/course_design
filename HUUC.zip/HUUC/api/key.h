#ifndef __KEY_H
#define __KEY_H

#include "iocc2530.h"

void Key_Init(void);
int Key_Read(void);

#endif
