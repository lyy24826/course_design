#ifndef __DS18B20_H
#define __DS18B20_H

#include "iocc2530.h"

unsigned char DS18B20_Init(void);
void DS18B20_WriteBit(unsigned char bitVal);
void DS18B20_WriteByte(unsigned char byteVal);
unsigned char DS18B20_ReadBit(void);
unsigned char DS18B20_ReadByte(void);
int DS18B20_GetTemperature(void);

#endif
