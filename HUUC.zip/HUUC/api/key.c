#include "key.h"
#include "delay.h"

void Key_Init(void)
{
  P0SEL &=~ 0x02;
  P0DIR &=~ 0x02;
  P0INP &=~ 0X02;
  P2INP |=  0X20;
  
  
  //����P0.7ͨ��IO
  P0SEL &=~ (0x80);
  //����P0.7����Ϊ����
  P0DIR &=~ (0x80);
  //����P0.7Ϊ������
  P0INP &=~ (0x80);
  //����P0.7Ϊ��������
  P2INP |=  (0x20);
  
  
  //��ʼP0.6��ADC
  APCFG |= (0x40);
}

unsigned int Adc_Value=0;
unsigned int ADC_GetValue(void)
{
  //��AVDD5Ϊ�ο���ѹ
  //��ȡ��Ϊ512
  //ʹ��AIN6ͨ��
  ADCCON3 |= (0xB6);
  //�ȴ�ת�����
  while((ADCCON1 & 0x80)!=0x80){}
  //��ȡ���
  Adc_Value = ADCH;
  Adc_Value = Adc_Value << 8;
  Adc_Value = Adc_Value | ADCL;
  Adc_Value = Adc_Value >> 2;

  return Adc_Value;
}




int Key_Read(void)
{
  if(P0_1==1)
  {
    Delay_xms(25);
    if(P0_1==1)
    {
      while(P0_1==1){}
      return 1;
    }
  }
  
  //P0.7����MID
  if(P0_7==1)
  {
    //��ʱ����
    Delay_xms(30);
    //�ٴ��ж�
    if(P0_7==1)
    {
      //�ȴ�����
      while(P0_7==1){}
      return 2;
    }
  }
  
  
  //UP
  if(2000<ADC_GetValue() && ADC_GetValue()<2400)
  {
    if(2000<ADC_GetValue() && ADC_GetValue()<2400)
    {
      while(2000<ADC_GetValue() && ADC_GetValue()<2400){}
      return 3;
    }
  }
  
  //DOWN
  if(2700<ADC_GetValue() && ADC_GetValue()<3100)
  {
    Delay_xms(50);
    if(2700<ADC_GetValue() && ADC_GetValue()<3100)
    {
      while(2700<ADC_GetValue() && ADC_GetValue()<3100){}
      return 4;
    }
  }
  
  
  //RIGHT
  if(4200<ADC_GetValue() && ADC_GetValue()<4600)
  {
    Delay_xms(50);
    if(4200<ADC_GetValue() && ADC_GetValue()<4600)
    {
      while(4200<ADC_GetValue() && ADC_GetValue()<4600){}
      return 5;
    }
  }
  
  //LEFT
  if(8000<ADC_GetValue())
  {
    Delay_xms(50);
    if(8000<ADC_GetValue())
    {
      while(8000<ADC_GetValue()){}
      return 6;
    }
  }
  
  
  
  return 0;
}

