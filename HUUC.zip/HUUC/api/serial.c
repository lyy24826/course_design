#include "serial.h"

void Serial_Init(void)
{
  PERCFG &=~ 0x01;
  P0SEL  |=  0x0C;
  U0BAUD =   59;
  U0GCR  =   8;
  U0UCR  |=  0x80;
  U0CSR  |=  0xC0;
}

void U0_SendByte(unsigned char data)
{
  U0DBUF = data;
  while(UTX0IF == 0);
  UTX0IF = 0;
}


void U0_SendStr(unsigned char * str)
{
  while(*str != '\0')
  {
    U0_SendByte(*str);
    str++;
  }
}



