#include "led.h"

void Led_Init(void)
{
  P1SEL &=~ 0x13;
  P1DIR |=  0X13;
  P1_0 = 1;
  P1_1 = 1;
  P1_4 = 1;
}