#ifndef __SERIAL_H
#define __SERIAL_H

#include "iocc2530.h"

void Serial_Init(void);
void U0_SendByte(unsigned char data);
void U0_SendStr(unsigned char * str);
#endif
