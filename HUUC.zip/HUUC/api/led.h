#ifndef __LED_H
#define __LED_H

#include "iocc2530.h"

#define G_ON    P1_0=1
#define R_ON    P1_1=1
#define Y_ON    P1_4=1

#define G_OFF   P1_0=0
#define R_OFF   P1_1=0
#define Y_OFF   P1_4=0

#define G_TURN  P1^=1<<0
#define R_TURN  P1^=1<<1
#define Y_TURN  P1^=1<<4

void Led_Init(void);

#endif
